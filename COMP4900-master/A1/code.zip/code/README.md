# A1

# How to Run COMP4900A1.pynb  Collab Notebook 
# 1. Download the bankrupcy.csv and  create a folder in under  MyDrive called ML and place the file there (My Drive/ML/bankrupcy.csv)
# 2. Download the hepatitis.csv and  create a folder in under  MyDrive called ML and place the file there (My Drive/ML/hepatitis.csv)
# 3. Upload the COMP4900A1.pynb file to Google Collab and open it up
# 4. Run the cell under Intial Set-up and follow the instruction to authorization the code base to allow to acces your My Drive
# 5. Click under Runtime and choose Run All.
# 6. Scroll down to the Results section to view results of experiment 



# Running Code from the local machine
# 1. Open up the terminal
# 2. change your working directory to be in the same 
# 3. Download the bankrupcy.csv and  create a folder  Data  and place the file there 
# 4. Download the hepatitis.csv and  create a folder  Data and place the file there
# 5. run python3 main.py